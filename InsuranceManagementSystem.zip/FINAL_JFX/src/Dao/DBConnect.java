package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect  {

	protected Connection connection;
	/*private static String url = "jdbc:mysql://www.papademas.net:3307/fp510";
	private static String username = "fpuser";
	private static String password = "510";*/
	private static String url = "jdbc:mysql://www.papademas.net:3307/510labs";
	private static String username = "db510";
	private static String password = "510";

	public DBConnect() {
		try {
			connection = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			System.out.println("Error creating connection to database: " + e);
			System.exit(-1);
		}
	}

	
}
