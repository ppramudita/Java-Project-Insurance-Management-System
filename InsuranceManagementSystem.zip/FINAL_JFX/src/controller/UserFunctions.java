package controller;

public interface UserFunctions {
	
	public String registerHomeCustomerPolicy() throws Exception;
	
	public String registerHealthCustomerPolicy();
    
	
}
